// sys2Dengine.c - Custom 2D Graphics Engine for Lumen OS (ARMv7a, Moto Nexus 6)
// Features: GUI rendering, compositors, motion/blur, multi-dimensional transforms
// Communicates with kernel via syscalls for framebuffer, input, memory mapping

#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <arm_neon.h>
#include <math.h>
#include "lumen_syscalls.h"  // Custom Lumen kernel interface
#include "lumen_framebuffer.h"  // Kernel-provided FB info
#include "sys2Dengine.h"

// Engine Configuration (scalable for Nexus 6: 1440x2560 @ 493ppi)
#define SCREEN_WIDTH  1440
#define SCREEN_HEIGHT 2560
#define BYTES_PER_PIXEL 4  // 32-bit ARGB8888 (Nexus 6 Adreno 418 compatible)
#define MAX_LAYERS     16
#define MAX_SPRITES    1024
#define MAX_ANIMS      256

// Color format: ARGB8888
typedef uint32_t color_t;

// Point, Rect, Matrix types for 2D transforms
typedef struct {
    int32_t x, y;
} point_t;

typedef struct {
    int32_t x, y, w, h;
} rect_t;

typedef struct {
    float m[3][3];  // Affine transform matrix (scale, rotate, translate)
} matrix_t;

// Layer structure for compositor (z-order, alpha blending, dirty rects)
typedef struct {
    rect_t bounds;
    color_t* buffer;     // Offscreen render target
    uint8_t alpha;
    uint8_t visible;
    uint8_t dirty;       // Mark for redraw
    matrix_t transform;
} layer_t;

// Sprite with motion (position, velocity, acceleration)
typedef struct {
    rect_t bounds;
    color_t* pixels;
    point_t pos, vel, accel;
    uint32_t frame_count;
    uint8_t anim_id;
} sprite_t;

// Animation state
typedef struct {
    uint32_t duration;
    uint32_t elapsed;
    float progress;
} anim_t;

// Core Engine Context
typedef struct {
    color_t* framebuffer;    // Direct kernel-mapped FB
    layer_t layers[MAX_LAYERS];
    sprite_t sprites[MAX_SPRITES];
    anim_t animations[MAX_ANIMS];
    uint32_t layer_count;
    uint32_t sprite_count;
    uint32_t anim_count;
    rect_t viewport;
    uint64_t timestamp;      // For delta-time motion
    int initialized;
} sys2d_engine_t;

static sys2d_engine_t engine = {0};

// Forward declarations
void matrix_identity(matrix_t* m);
void matrix_multiply(matrix_t* dst, const matrix_t* a, const matrix_t* b);
void blend_pixel(color_t* dst, color_t src, uint8_t alpha);
void fill_rect(layer_t* layer, rect_t* rect, color_t color);

// Kernel communication syscalls (Lumen-specific)
static inline int sys_framebuffer_map(void** addr, size_t* size) {
    return lumen_syscall3(LUMEN_SYSCALL_FB_MAP, (uint64_t)addr, (uint64_t)size, 0);
}

static inline int sys_framebuffer_unmap(void* addr, size_t size) {
    return lumen_syscall2(LUMEN_SYSCALL_FB_UNMAP, (uint64_t)addr, size);
}

static inline int sys_input_poll(point_t* touch_pos, int* buttons) {
    return lumen_syscall3(LUMEN_SYSCALL_INPUT_POLL, (uint64_t)touch_pos, (uint64_t)buttons, 0);
}

static inline uint64_t sys_timestamp(void) {
    return lumen_syscall0(LUMEN_SYSCALL_TIMESTAMP);
}

// === MATRIX OPERATIONS (2D Transforms: Scale, Rotate, Translate) ===
void matrix_identity(matrix_t* m) {
    memset(m->m, 0, sizeof(m->m));
    m->m[0][0] = m->m[1][1] = m->m[2][2] = 1.0f;
}

void matrix_translate(matrix_t* m, float tx, float ty) {
    matrix_t t = {{{1,0,0}, {0,1,0}, {tx,ty,1}}};
    matrix_multiply(m, &t, m);
}

void matrix_scale(matrix_t* m, float sx, float sy) {
    matrix_t s = {{{sx,0,0}, {0,sy,0}, {0,0,1}}};
    matrix_multiply(m, &s, m);
}

void matrix_rotate(matrix_t* m, float radians) {
    float c = cosf(radians), s = sinf(radians);
    matrix_t r = {{{c,-s,0}, {s,c,0}, {0,0,1}}};
    matrix_multiply(m, &r, m);
}

void matrix_multiply(matrix_t* dst, const matrix_t* a, const matrix_t* b) {
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            dst->m[i][j] = a->m[i][0] * b->m[0][j] +
                           a->m[i][1] * b->m[1][j] +
                           a->m[i][2] * b->m[2][j];
        }
    }
}

// === RENDERING PRIMITIVES ===
void blend_pixel(color_t* dst, color_t src, uint8_t alpha) {
    if (alpha == 255) {
        *dst = src;
        return;
    }
    uint8_t da = (*dst >> 24) & 0xFF;
    uint8_t sa = (src >> 24) & 0xFF;
    // Simple alpha blend (premultiplied alpha for perf on ARMv7a NEON)
    uint32_t r = (((src >> 16) & 0xFF) * alpha * sa + ((*dst >> 16) & 0xFF) * (255 - alpha)) >> 16;
    uint32_t g = (((src >>  8) & 0xFF) * alpha * sa + ((*dst >>  8) & 0xFF) * (255 - alpha)) >> 16;
    uint32_t b = (((src      ) & 0xFF) * alpha * sa + ((*dst      ) & 0xFF) * (255 - alpha)) >> 16;
    *dst = (255 << 24) | (r << 16) | (g << 8) | b;
}

void fill_rect(layer_t* layer, rect_t* rect, color_t color) {
    if (!layer || !rect || rect->w <= 0 || rect->h <= 0) return;
    int x1 = rect->x, y1 = rect->y, x2 = x1 + rect->w, y2 = y1 + rect->h;
    for (int y = y1; y < y2; y++) {
        for (int x = x1; x < x2; x++) {
            color_t* px = &layer->buffer[y * layer->bounds.w + x];
            blend_pixel(px, color, 255);
        }
    }
    layer->dirty = 1;
}

// Transform point by matrix (for motion/dimensions)
point_t transform_point(const matrix_t* mat, point_t p) {
    float x = p.x * mat->m[0][0] + p.y * mat->m[0][1] + mat->m[0][2];
    float y = p.x * mat->m[1][0] + p.y * mat->m[1][1] + mat->m[1][2];
    return (point_t){(int)x, (int)y};
}

// === COMPOSITOR (Layer Blending) ===
void composite_layers(void) {
    for (int i = 0; i < engine.layer_count; i++) {
        layer_t* layer = &engine.layers[i];
        if (!layer->visible || !layer->dirty) continue;
        
        // Blit layer to framebuffer with transform/alpha
        for (int y = 0; y < layer->bounds.h; y++) {
            for (int x = 0; x < layer->bounds.w; x++) {
                point_t src_p = {x, y};
                point_t dst_p = transform_point(&layer->transform, src_p);
                if (dst_p.x >= 0 && dst_p.x < SCREEN_WIDTH && dst_p.y >= 0 && dst_p.y < SCREEN_HEIGHT) {
                    int fb_idx = dst_p.y * SCREEN_WIDTH + dst_p.x;
                    int layer_idx = y * layer->bounds.w + x;
                    blend_pixel(&engine.framebuffer[fb_idx], layer->buffer[layer_idx], layer->alpha);
                }
            }
        }
        layer->dirty = 0;
    }
}

// === MOTION SYSTEM (Physics + Animation) ===
void update_motion(void) {
    uint64_t now = sys_timestamp();
    float delta = (now - engine.timestamp) / 1000000000.0f;  // ns to sec
    engine.timestamp = now;
    
    for (int i = 0; i < engine.sprite_count; i++) {
        sprite_t* spr = &engine.sprites[i];
        spr->vel.x += spr->accel.x * delta;
        spr->vel.y += spr->accel.y * delta;
        spr->pos.x += spr->vel.x * delta;
        spr->pos.y += spr->vel.y * delta;
        spr->bounds.x = spr->pos.x;
        spr->bounds.y = spr->pos.y;
    }
    
    // Update animations
    for (int i = 0; i < engine.anim_count; i++) {
        engine.animations[i].elapsed += delta * 1000;
        engine.animations[i].progress = engine.animations[i].elapsed / engine.animations[i].duration;
        if (engine.animations[i].progress >= 1.0f) {
            // Loop or remove
            engine.animations[i].elapsed = 0;
        }
    }
}

// === GUI SYSTEM (Buttons, Panels, etc.) ===
typedef struct {
    rect_t bounds;
    char text[64];
    int (*callback)(void);
    color_t bg_color, text_color;
} gui_element_t;

gui_element_t gui_elements[32];
uint32_t gui_count = 0;

void gui_render(void) {
    layer_t* gui_layer = &engine.layers[0];  // Assume layer 0 is GUI
    for (int i = 0; i < gui_count; i++) {
        gui_element_t* el = &gui_elements[i];
        fill_rect(gui_layer, &el->bounds, el->bg_color);
        // TODO: Text rendering (bitmap font)
    }
    gui_layer->dirty = 1;
}

int gui_handle_touch(point_t* touch) {
    for (int i = gui_count - 1; i >= 0; i--) {  // Back-to-front hit test
        if (touch->x >= gui_elements[i].bounds.x &&
            touch->x < gui_elements[i].bounds.x + gui_elements[i].bounds.w &&
            touch->y >= gui_elements[i].bounds.y &&
            touch->y < gui_elements[i].bounds.y + gui_elements[i].bounds.h) {
            return gui_elements[i].callback ? gui_elements[i].callback() : 0;
        }
    }
    return 0;
}

// === PUBLIC API ===
int sys2d_init(void) {
    if (engine.initialized) return 0;
    
    // Map kernel framebuffer (Moto Nexus 6: /dev/graphics/fb0 equivalent)
    size_t fb_size;
    if (sys_framebuffer_map((void**)&engine.framebuffer, &fb_size) != 0) {
        return -1;  // Kernel comm failed
    }
    
    // Init layers (backbuffer alloc via kernel mmap)
    for (int i = 0; i < MAX_LAYERS; i++) {
        layer_t* l = &engine.layers[i];
        l->buffer = lumen_malloc(SCREEN_WIDTH * SCREEN_HEIGHT * BYTES_PER_PIXEL);
        if (!l->buffer) return -1;
        matrix_identity(&l->transform);
        l->alpha = 255;
        l->visible = 1;
    }
    
    engine.viewport = (rect_t){0, 0, SCREEN_WIDTH, SCREEN_HEIGHT};
    engine.timestamp = sys_timestamp();
    engine.initialized = 1;
    return 0;
}

void sys2d_create_layer(rect_t bounds, int layer_id) {
    if (layer_id < 0 || layer_id >= MAX_LAYERS) return;
    engine.layers[layer_id].bounds = bounds;
    engine.layers[layer_id].dirty = 1;
    if (engine.layer_count <= layer_id) engine.layer_count = layer_id + 1;
}

void sys2d_add_sprite(rect_t bounds, color_t* pixels, int sprite_id) {
    if (sprite_id < 0 || sprite_id >= MAX_SPRITES) return;
    engine.sprites[sprite_id] = (sprite_t){bounds, pixels, {bounds.x, bounds.y}, {0}, {0}};
    engine.sprite_count++;
}

void sys2d_render(void) {
    update_motion();
    gui_render();
    composite_layers();
    // Trigger kernel VSYNC flip
    lumen_syscall0(LUMEN_SYSCALL_VSYNC);
}

void sys2d_shutdown(void) {
    if (!engine.initialized) return;
    sys_framebuffer_unmap(engine.framebuffer, SCREEN_WIDTH * SCREEN_HEIGHT * BYTES_PER_PIXEL);
    // Free layers/sprites
    engine.initialized = 0;
}

// ---- Frame Syncing ----

// Frame Syncing System (VSYNC + Adaptive Sync for 60Hz Nexus 6 display)
// Appended to sys2Dengine.c - handles tear-free rendering, frame pacing, dropped frames

// Frame timing configuration (Nexus 6: 60Hz = 16.67ms per frame)
#define TARGET_FPS       60
#define FRAME_TIME_NS    (1000000000ULL / TARGET_FPS)  // ~16.67ms
#define MAX_FRAMESKIP    2
#define VSYNC_TOLERANCE  1666667  // 1.5ms tolerance

// Frame stats for debugging/perf monitoring
typedef struct {
    uint64_t frame_start;
    uint64_t frame_end;
    uint64_t vsync_time;
    uint32_t frame_count;
    uint32_t missed_frames;
    float avg_frame_time;
    uint8_t vsync_locked;
} frame_stats_t;

static frame_stats_t frame_stats = {0};

// VSYNC kernel syscall (waits for hardware vertical blanking)
static inline int sys_vsync_wait(void) {
    return lumen_syscall0(LUMEN_SYSCALL_VSYNC_WAIT);
}

// High-precision timestamp diff (ARMv7a cycle counter fallback)
static inline uint64_t time_diff_ns(uint64_t end, uint64_t start) {
    return end - start;
}

// Adaptive frame pacing - sleeps to hit target framerate
static void adaptive_sleep(uint64_t target_time) {
    uint64_t now = sys_timestamp();
    int64_t sleep_ns = target_time - now;
    
    if (sleep_ns > 1000000) {  // Sleep only for >1ms (avoid tiny sleeps)
        // Kernel sleep syscall (Lumen-specific, ns granularity)
        lumen_syscall1(LUMEN_SYSCALL_NANOSLEEP, sleep_ns);
    }
}

// === ENHANCED RENDER LOOP WITH FRAME SYNCING ===
void sys2d_render_sync(void) {
    uint64_t frame_start = sys_timestamp();
    static uint64_t next_frame_target = 0;
    static uint32_t frame_skip = 0;
    
    // Frame pacing: skip frames if we're behind
    if (time_diff_ns(frame_start, next_frame_target) > FRAME_TIME_NS * MAX_FRAMESKIP) {
        frame_stats.missed_frames++;
        frame_skip++;
        if (frame_skip > MAX_FRAMESKIP) {
            // Emergency reset - don't skip forever
            frame_skip = 0;
            next_frame_target = frame_start + FRAME_TIME_NS;
            return;
        }
    }
    
    // Update game logic/motion (fixed timestep for consistency)
    update_motion();
    gui_render();
    
    // Measure render time
    uint64_t render_start = sys_timestamp();
    composite_layers();
    uint64_t render_end = sys_timestamp();
    
    // Wait for VSYNC (hardware tear-free flip)
    frame_stats.vsync_time = sys_timestamp();
    int vsync_result = sys_vsync_wait();
    frame_stats.vsync_locked = (vsync_result == 0);
    
    // Swapbuffers (kernel handles FB flip)
    lumen_syscall0(LUMEN_SYSCALL_FB_SWAP);
    
    // Frame complete timing
    frame_stats.frame_end = sys_timestamp();
    uint64_t frame_time = time_diff_ns(frame_stats.frame_end, frame_start);
    
    // Update stats
    frame_stats.frame_count++;
    frame_stats.avg_frame_time = (frame_stats.avg_frame_time * 0.9f) + (frame_time / 1000000.0f * 0.1f);
    
    // Calculate next frame target (adaptive +/- tolerance)
    next_frame_target = frame_stats.frame_end + FRAME_TIME_NS;
    if (time_diff_ns(next_frame_target, frame_start) > VSYNC_TOLERANCE) {
        next_frame_target -= VSYNC_TOLERANCE;  // Pull forward slightly if early
    }
    
    // Sleep to target time if we finished early
    adaptive_sleep(next_frame_target);
    
    frame_stats.frame_start = frame_start;
    frame_skip = 0;  // Reset skip counter
}

// Frame stats query for debugging (kernel console output)
void sys2d_debug_stats(void) {
    char stats_buf[256];
    int len = snprintf(stats_buf, sizeof(stats_buf),
        "FPS: %.1f | Frame: %.2fms | VSync: %s | Missed: %u | Total: %u
",
        1000.0f / frame_stats.avg_frame_time,
        frame_stats.avg_frame_time,
        frame_stats.vsync_locked ? "LOCKED" : "DRIFT",
        frame_stats.missed_frames,
        frame_stats.frame_count);
    
    // Kernel debug print syscall
    lumen_syscall2(LUMEN_SYSCALL_DEBUG_PRINT, (uint64_t)stats_buf, len);
}

// === PUBLIC API UPDATE - Replace sys2d_render() calls with this ===
/*
void sys2d_render(void) {
    sys2d_render_sync();  // Now with VSYNC + frame pacing!
}
*/

// Input polling with frame timing (non-blocking, 60Hz polling)
int sys2d_poll_input(point_t* touch_pos, int* buttons) {
    static uint64_t last_input_poll = 0;
    uint64_t now = sys_timestamp();
    
    // Poll input at most 60Hz (avoid spam)
    if (time_diff_ns(now, last_input_poll) < FRAME_TIME_NS) {
        touch_pos->x = touch_pos->y = 0;
        *buttons = 0;
        return 0;
    }
    
    last_input_poll = now;
    return sys_input_poll(touch_pos, buttons);
}

// === MAIN LOOP EXAMPLE (Updated with Frame Syncing) ===
/*
Example usage in main Lumen app loop:
sys2d_init();
sys2d_create_layer((rect_t){0,0,SCREEN_WIDTH,SCREEN_HEIGHT}, 0);

while (1) {
    point_t touch = {0};
    int buttons;
    
    // Synced input polling
    sys2d_poll_input(&touch, &buttons);
    if (buttons) gui_handle_touch(&touch);
    
    // Synced rendering (60FPS VSYNC locked)
    sys2d_render_sync();
    
    // Debug stats every 100 frames
    if (frame_stats.frame_count % 100 == 0) {
        sys2d_debug_stats();
    }
}
*/

// ---- FPS Displayer (Enable in sys2Dengine.flags by flipping the FPSDISPLAY flag to TRUE. FPSDISPLAY flag is set to FALSE by default) ----

// Engine flags (bitfield for features like FPS display)
typedef enum {
    FPSDISPLAY = (1 << 0),  // Bit 0: Show FPS overlay
    DEBUG_WIREFRAME = (1 << 1),
    VSYNC_ONLY = (1 << 2)
} engine_flags_t;

static uint32_t engine_flags = 0;  // Default: no flags enabled

// FPS Display configuration (top-left corner overlay)
#define FPS_X          10
#define FPS_Y          20
#define FPS_WIDTH     200
#define FPS_HEIGHT     80
#define FPS_UPDATE_MS  250  // Update every 250ms for stable reading

// Simple 5x7 bitmap font (fixed-width, 6px wide incl. spacing)
// Only digits 0-9 + decimal + basic chars for FPS display
static const uint8_t font5x7[128][5] = {
    // '0' (48)
    [48] = {0x7D, 0x12, 0x12, 0x12, 0x7D},  // 0
    [49] = {0x00, 0x22, 0x7F, 0x20, 0x20},  // 1
    [50] = {0x3E, 0x41, 0x49, 0x41, 0x26},  // 2
    [51] = {0x7F, 0x09, 0x09, 0x09, 0x7D},  // 3
    [52] = {0x0F, 0x28, 0x28, 0x28, 0x1F},  // 4 (narrower)
    [53] = {0x7F, 0x40, 0x7E, 0x01, 0x7E},  // 5
    [54] = {0x7C, 0x42, 0x5B, 0x41, 0x3E},  // 6
    [55] = {0x7F, 0x08, 0x08, 0x08, 0x08},  // 7
    [58] = {0x00, 0x44, 0x00, 0x00, 0x44},  // :
    [46] = {0x00, 0x00, 0x00, 0x00, 0x40},  // .
    [70] = {0x7F, 0x40, 0x40, 0x40, 0x40},  // F
    [80] = {0x7C, 0x42, 0x42, 0x42, 0x7C},  // P
    [83] = {0x3E, 0x41, 0x41, 0x41, 0x3E},  // S
};

// FPS overlay layer (always rendered on top)
static layer_t fps_layer = {0};
static uint64_t fps_last_update = 0;
static float fps_display = 0.0f;
static char fps_text[16] = "60.0 FPS";

// Enable/disable FPS display flag
void sys2d_set_fps_display(int enable) {
    if (enable) {
        engine_flags |= FPSDISPLAY;
        // Init FPS layer if not already
        if (!fps_layer.buffer) {
            fps_layer.bounds = (rect_t){FPS_X, FPS_Y, FPS_WIDTH, FPS_HEIGHT};
            fps_layer.buffer = lumen_malloc(FPS_WIDTH * FPS_HEIGHT * BYTES_PER_PIXEL);
            fps_layer.alpha = 220;  // Semi-transparent overlay
            fps_layer.visible = 1;
        }
    } else {
        engine_flags &= ~FPSDISPLAY;
        fps_layer.visible = 0;
    }
}

// Draw a single 5x7 character at position (x,y) on target layer
static void draw_char(layer_t* target, int x, int y, char ch, color_t fg, color_t bg) {
    if (ch < 32 || ch > 127) return;
    const uint8_t* glyph = font5x7[(uint8_t)ch];
    
    for (int gy = 0; gy < 7; gy++) {
        for (int gx = 0; gx < 5; gx++) {
            if (glyph[gy] & (1 << (4 - gx))) {  // Bitmapped font
                int px = x + gx * 2;  // 2px scaling for readability
                int py = y + gy * 2;
                if (px >= 0 && px < target->bounds.w && py >= 0 && py < target->bounds.h) {
                    color_t* pixel = &target->buffer[py * target->bounds.w + px];
                    blend_pixel(pixel, fg, 255);
                }
            }
        }
    }
}

// Render FPS text overlay
static void render_fps_overlay(void) {
    if (!(engine_flags & FPSDISPLAY) || !fps_layer.buffer) return;
    
    uint64_t now = sys_timestamp();
    if (time_diff_ns(now, fps_last_update) < FPS_UPDATE_MS * 1000000ULL) {
        return;  // Throttle updates
    }
    fps_last_update = now;
    
    // Clear FPS layer with semi-transparent black background
    color_t bg_color = (80 << 24) | (20 << 16) | (20 << 8) | 20;  // Dark semi-transparent
    fill_rect(&fps_layer, &(rect_t){0, 0, FPS_WIDTH, FPS_HEIGHT}, bg_color);
    
    // Render "FPS: XX.X" text
    color_t fg_color = 0xFF00FF00;  // Bright green
    color_t white = 0xFFFFFFFF;
    
    int x = 4, y = 8;
    draw_char(&fps_layer, x, y, 'F', white, bg_color); x += 14;
    draw_char(&fps_layer, x, y, 'P', white, bg_color); x += 14;
    draw_char(&fps_layer, x, y, 'S', white, bg_color); x += 16;
    draw_char(&fps_layer, x, y, ':', fg_color, bg_color); x += 12;
    
    // Render FPS value (convert float to digits)
    char fps_str[8];
    snprintf(fps_str, sizeof(fps_str), "%.1f", fps_display);
    for (int i = 0; fps_str[i] && x < FPS_WIDTH - 10; i++) {
        draw_char(&fps_layer, x, y + 2, fps_str[i], fg_color, bg_color);
        x += 14;
    }
    
    // Add "ms" indicator
    x = 4; y += 24;
    draw_char(&fps_layer, x, y, 'm', white, bg_color); x += 14;
    draw_char(&fps_layer, x, y, 's', white, bg_color); x += 14;
    
    snprintf(fps_str, sizeof(fps_str), "%.1f", frame_stats.avg_frame_time);
    for (int i = 0; fps_str[i] && x < FPS_WIDTH - 10; i++) {
        draw_char(&fps_layer, x, y + 2, fps_str[i], fg_color, bg_color);
        x += 14;
    }
    
    fps_layer.dirty = 1;  // Mark for compositing
}

// Updated render function - automatically handles FPS overlay
void sys2d_render_sync(void) {
    uint64_t frame_start = sys_timestamp();
    static uint64_t next_frame_target = 0;
    static uint32_t frame_skip = 0;
    
    // [Previous frame syncing code unchanged...]
    if (time_diff_ns(frame_start, next_frame_target) > FRAME_TIME_NS * MAX_FRAMESKIP) {
        frame_stats.missed_frames++;
        frame_skip++;
        if (frame_skip > MAX_FRAMESKIP) {
            frame_skip = 0;
            next_frame_target = frame_start + FRAME_TIME_NS;
            return;
        }
    }
    
    update_motion();
    gui_render();
    
    uint64_t render_start = sys_timestamp();
    composite_layers();
    
    // NEW: Render FPS overlay on top layer (always visible when enabled)
    render_fps_overlay();
    
    uint64_t render_end = sys_timestamp();
    
    frame_stats.vsync_time = sys_timestamp();
    int vsync_result = sys_vsync_wait();
    frame_stats.vsync_locked = (vsync_result == 0);
    
    lumen_syscall0(LUMEN_SYSCALL_FB_SWAP);
    
    frame_stats.frame_end = sys_timestamp();
    uint64_t frame_time = time_diff_ns(frame_stats.frame_end, frame_start);
    
    // UPDATE FPS DISPLAY VALUE
    frame_stats.frame_count++;
    frame_stats.avg_frame_time = (frame_stats.avg_frame_time * 0.9f) + (frame_time / 1000000.0f * 0.1f);
    fps_display = 1000.0f / frame_stats.avg_frame_time;
    
    next_frame_target = frame_stats.frame_end + FRAME_TIME_NS;
    if (time_diff_ns(next_frame_target, frame_start) > VSYNC_TOLERANCE) {
        next_frame_target -= VSYNC_TOLERANCE;
    }
    
    adaptive_sleep(next_frame_target);
    frame_stats.frame_start = frame_start;
    frame_skip = 0;
}

// Public API to toggle FPS display
void sys2d_toggle_fps_display(void) {
    sys2d_set_fps_display( !(engine_flags & FPSDISPLAY) );
}

// Init function update - FPS layer setup
int sys2d_init(void) {
    if (engine.initialized) return 0;
    
    // [Previous init code...]
    size_t fb_size;
    if (sys_framebuffer_map((void**)&engine.framebuffer, &fb_size) != 0) {
        return -1;
    }
    
    for (int i = 0; i < MAX_LAYERS; i++) {
        layer_t* l = &engine.layers[i];
        l->buffer = lumen_malloc(SCREEN_WIDTH * SCREEN_HEIGHT * BYTES_PER_PIXEL);
        if (!l->buffer) return -1;
        matrix_identity(&l->transform);
        l->alpha = 255;
        l->visible = 1;
    }
    
    // Add FPS layer as topmost layer (index MAX_LAYERS-1)
    engine.layers[MAX_LAYERS-1] = fps_layer;
    engine.layer_count = MAX_LAYERS;
    
    engine.viewport = (rect_t){0, 0, SCREEN_WIDTH, SCREEN_HEIGHT};
    engine.timestamp = sys_timestamp();
    engine.initialized = 1;
    engine_flags = 0;  // FPS display OFF by default
    
    return 0;
}

// Usage: Enable FPS display in your main loop:
// sys2d_set_fps_display(1);  // OR sys2d_toggle_fps_display();
// Now FPS + frame time shows in top-left corner automatically!

// ---- GUI Freeze Warning (Show Up as a White noise covering the entire screen then Close apps and Restart GUI) ----
// Detects 10 seconds of 0 FPS, shows full-screen white noise, kills apps, restarts GUI

// Freeze detection configuration
#define FREEZE_THRESHOLD_SEC   10
#define FREEZE_CHECK_INTERVAL  1000000000ULL  // 1 sec in ns
#define WHITE_NOISE_DURATION   2000000000ULL  // 2 sec warning

// Freeze states
typedef enum {
    FREEZE_NORMAL = 0,
    FREEZE_WARNING,
    FREEZE_RESTARTING
} freeze_state_t;

static freeze_state_t freeze_state = FREEZE_NORMAL;
static uint64_t freeze_start_time = 0;
static uint64_t last_freeze_check = 0;
static uint8_t white_noise_pattern[SCREEN_WIDTH][SCREEN_HEIGHT/8];  // 1-bit noise pattern

// Kernel syscalls for emergency restart
static inline int sys_kill_all_apps(void) {
    return lumen_syscall0(LUMEN_SYSCALL_KILL_ALL_APPS);
}

static inline int sys_restart_gui(void) {
    return lumen_syscall0(LUMEN_SYSCALL_RESTART_GUI);
}

static inline int sys_generate_random(void* buffer, size_t size) {
    return lumen_syscall2(LUMEN_SYSCALL_RANDOM, (uint64_t)buffer, size);
}

// Generate white noise pattern (static TV snow effect)
static void generate_white_noise(void) {
    sys_generate_random(white_noise_pattern, sizeof(white_noise_pattern));
}

// Full-screen white noise overlay layer
static layer_t freeze_layer = {0};

// Show freeze warning (full-screen white noise)
static void show_freeze_warning(void) {
    if (!freeze_layer.buffer) {
        freeze_layer.bounds = (rect_t){0, 0, SCREEN_WIDTH, SCREEN_HEIGHT};
        freeze_layer.buffer = lumen_malloc(SCREEN_WIDTH * SCREEN_HEIGHT * BYTES_PER_PIXEL);
        freeze_layer.alpha = 255;
        freeze_layer.visible = 1;
        generate_white_noise();
    }
    
    // Render animated white noise (TV static effect)
    uint64_t now = sys_timestamp();
    static uint64_t noise_seed = 0;
    noise_seed += time_diff_ns(now, last_freeze_check);
    
    for (int y = 0; y < SCREEN_HEIGHT; y += 8) {
        for (int x = 0; x < SCREEN_WIDTH; x++) {
            uint8_t noise = white_noise_pattern[x][y/8];
            // Animate noise with time-based scrolling
            if ((noise_seed + x + y) & 0x7F) {
                color_t noise_color = ((255 ^ (x^y^noise_seed)) << 24) | 
                                    (192 << 16) | (192 << 8) | 192;  // Bright white-ish
                for (int py = 0; py < 8 && y+py < SCREEN_HEIGHT; py++) {
                    color_t* pixel = &freeze_layer.buffer[(y+py) * SCREEN_WIDTH + x];
                    blend_pixel(pixel, noise_color, 255);
                }
            }
        }
    }
    freeze_layer.dirty = 1;
    
    // Show "GUI FROZEN - RESTARTING..." text in center
    color_t red = 0xFFFF0000;
    char* freeze_msg = "GUI FROZEN - RESTARTING IN 2s...";
    int msg_x = (SCREEN_WIDTH - strlen(freeze_msg) * 12) / 2;
    int msg_y = SCREEN_HEIGHT / 2 - 20;
    
    for (int i = 0; freeze_msg[i]; i++) {
        draw_char(&freeze_layer, msg_x + i * 12, msg_y, freeze_msg[i], red, 0);
    }
}

// Freeze detection and recovery
static void check_freeze_condition(void) {
    uint64_t now = sys_timestamp();
    
    // Throttled freeze checks (every 1 second)
    if (time_diff_ns(now, last_freeze_check) < FREEZE_CHECK_INTERVAL) {
        return;
    }
    last_freeze_check = now;
    
    // Check for 0 FPS condition
    if (fps_display < 1.0f) {  // FPS at 0
        if (freeze_state == FREEZE_NORMAL) {
            freeze_start_time = now;
            freeze_state = FREEZE_WARNING;
        } else if (freeze_state == FREEZE_WARNING) {
            if (time_diff_ns(now, freeze_start_time) > FREEZE_THRESHOLD_SEC * 1000000000ULL) {
                freeze_state = FREEZE_RESTARTING;
                
                // Emergency recovery sequence
                sys_kill_all_apps();  // Close all user apps
                
                uint64_t restart_time = now + WHITE_NOISE_DURATION;
                while (time_diff_ns(sys_timestamp(), restart_time) < 0) {
                    show_freeze_warning();
                    composite_layers();  // Force render warning
                    sys_vsync_wait();
                }
                
                sys_restart_gui();  // Restart GUI subsystem
                engine.initialized = 0;  // Force re-init
                return;
            }
        }
    } else {
        // Normal FPS - reset freeze state
        freeze_state = FREEZE_NORMAL;
        freeze_layer.visible = 0;
    }
}

// Integrate into main render loop
void sys2d_render_sync(void) {
    uint64_t frame_start = sys_timestamp();
    static uint64_t next_frame_target = 0;
    static uint32_t frame_skip = 0;
    
    // Frame skipping logic [unchanged...]
    if (time_diff_ns(frame_start, next_frame_target) > FRAME_TIME_NS * MAX_FRAMESKIP) {
        frame_stats.missed_frames++;
        frame_skip++;
        if (frame_skip > MAX_FRAMESKIP) {
            frame_skip = 0;
            next_frame_target = frame_start + FRAME_TIME_NS;
            return;
        }
    }
    
    // CRITICAL: Freeze detection FIRST (before any rendering)
    check_freeze_condition();
    
    if (freeze_state == FREEZE_RESTARTING) {
        return;  // Block all rendering during restart
    }
    
    update_motion();
    gui_render();
    
    uint64_t render_start = sys_timestamp();
    composite_layers();
    
    // FPS overlay (only if not freezing)
    if (!(freeze_state == FREEZE_WARNING || freeze_state == FREEZE_RESTARTING)) {
        render_fps_overlay();
    }
    
    // Freeze warning overlay (highest priority)
    if (freeze_state == FREEZE_WARNING) {
        show_freeze_warning();
        composite_layers();  // Re-composite with warning on top
    }
    
    uint64_t render_end = sys_timestamp();
    
    // VSYNC and timing [unchanged...]
    frame_stats.vsync_time = sys_timestamp();
    int vsync_result = sys_vsync_wait();
    frame_stats.vsync_locked = (vsync_result == 0);
    
    lumen_syscall0(LUMEN_SYSCALL_FB_SWAP);
    
    frame_stats.frame_end = sys_timestamp();
    uint64_t frame_time = time_diff_ns(frame_stats.frame_end, frame_start);
    
    frame_stats.frame_count++;
    frame_stats.avg_frame_time = (frame_stats.avg_frame_time * 0.9f) + (frame_time / 1000000000.0f * 0.1f);
    fps_display = 1000.0f / frame_stats.avg_frame_time;
    
    next_frame_target = frame_stats.frame_end + FRAME_TIME_NS;
    if (time_diff_ns(next_frame_target, frame_start) > VSYNC_TOLERANCE) {
        next_frame_target -= VSYNC_TOLERANCE;
    }
    
    adaptive_sleep(next_frame_target);
    frame_stats.frame_start = frame_start;
    frame_skip = 0;
}

// Public API to manually trigger freeze recovery (debug)
void sys2d_force_freeze_recovery(void) {
    freeze_state = FREEZE_RESTARTING;
}

// Init update - pre-allocate freeze layer
int sys2d_init(void) {
    // [Previous init code unchanged...]
    
    // Pre-allocate freeze warning layer as topmost (index MAX_LAYERS)
    engine.layers[MAX_LAYERS-1] = freeze_layer;
    engine.layer_count = MAX_LAYERS;
    
    // Generate initial noise pattern
    generate_white_noise();
    
    engine.initialized = 1;
    return 0;
}

// ---- Random Funny Events (Easter eggs for Lumen OS developers) ----
// Triggers randomly during normal operation - keeps development fun!
// 0.1% chance per frame (~3 events/hour at 60FPS). Completely optional.

// Funny event types (non-intrusive, dev-only easter eggs)
typedef enum {
    EVENT_RAINBOW_BARF = 0,    // Screen explodes in rainbow colors
    EVENT_DANCING_CURSOR,      // Big pixel cursor moonwalks across screen
    EVENT_FPS_RICKROLL,        // FPS counter becomes "Never gonna give you up"
    EVENT_INVERT_SCREEN,       // Screen inverts for 3 seconds
    EVENT_GEOMETRY_DASH,       // Tiny GD icon bounces around (your favorite!)
    EVENT_LUMEN_LOGO_SPIN,     // Lumen logo rotates in center
    EVENT_CAT_MEME,            // ASCII cat appears in corner
    NUM_FUNNY_EVENTS
} funny_event_t;

#define FUNNY_EVENT_CHANCE    1000     // 1/1000 frames (~0.1% at 60FPS)
#define MAX_EVENT_LAYERS      4

static uint32_t funny_seed = 12345;
static uint8_t funny_events_enabled = 1;
static funny_event_t active_event = -1;
static uint64_t event_start_time = 0;
static layer_t funny_layers[MAX_EVENT_LAYERS];

// Fast PRNG for events (ARM-optimized)
static uint32_t funny_rand(void) {
    funny_seed = funny_seed * 1103515245 + 12345;
    return (funny_seed >> 16) & 0x7FFF;
}

// Pre-defined funny patterns/colors
static const color_t rainbow_colors[7] = {
    0xFFFF0000, 0xFFFF7F00, 0xFFFFFF00, 0xFF00FF00,
    0xFF0000FF, 0xFF7F00FF, 0xFFFF00FF
};

// Trigger random funny event
static void trigger_funny_event(void) {
    if (!funny_events_enabled || active_event != -1) return;
    
    active_event = (funny_event_t)(funny_rand() % NUM_FUNNY_EVENTS);
    event_start_time = sys_timestamp();
    
    // Clear previous funny layers
    for (int i = 0; i < MAX_EVENT_LAYERS; i++) {
        funny_layers[i].visible = 0;
    }
    
    // Quick flash + sound (kernel beep syscall)
    color_t flash_color = rainbow_colors[funny_rand() % 7];
    fill_rect(&engine.layers[0], &engine.viewport, flash_color);
    lumen_syscall1(LUMEN_SYSCALL_BEEP, 800);  // Funny "boop!"
}

// Update active funny event
static void update_funny_event(void) {
    if (active_event == -1) {
        // Check for new event trigger (low probability)
        if (funny_rand() % FUNNY_EVENT_CHANCE == 0) {
            trigger_funny_event();
        }
        return;
    }
    
    uint64_t now = sys_timestamp();
    uint64_t event_duration = time_diff_ns(now, event_start_time);
    
    switch (active_event) {
        case EVENT_RAINBOW_BARF: {
            // Screen fills with scrolling rainbow bars
            static float rainbow_offset = 0;
            rainbow_offset += 0.1f;
            for (int y = 0; y < SCREEN_HEIGHT; y++) {
                color_t bar_color = rainbow_colors[(int)(y * 0.1f + rainbow_offset) % 7];
                fill_rect(&engine.layers[0], &(rect_t){0, y, SCREEN_WIDTH, 1}, bar_color);
            }
            if (event_duration > 2000000000ULL) {  // 2 sec
                active_event = -1;
            }
            break;
        }
        
        case EVENT_DANCING_CURSOR: {
            // Big 32x32 pixel cursor moonwalks left-right
            static int cursor_x = 0;
            static int direction = 1;
            cursor_x += direction * 8;
            if (cursor_x > SCREEN_WIDTH - 32 || cursor_x < 0) direction = -direction;
            
            // Simple cursor bitmap (arrow)
            color_t cursor_color = 0xFFFFFFFF;
            for (int y = 100; y < 132; y++) {
                for (int x = cursor_x; x < cursor_x + 32; x++) {
                    if ((x - cursor_x) ^ (y - 100) < 16) {  // Diamond cursor
                        blend_pixel(&engine.framebuffer[y * SCREEN_WIDTH + x], cursor_color, 255);
                    }
                }
            }
            if (event_duration > 3000000000ULL) active_event = -1;
            break;
        }
        
        case EVENT_GEOMETRY_DASH: {
            // Tiny Geometry Dash cube bounces (your favorite game!)
            static point_t gd_pos = {100, 100};
            static point_t gd_vel = {5, 3};
            
            gd_pos.x += gd_vel.x;
            gd_pos.y += gd_vel.y;
            if (gd_pos.x < 0 || gd_pos.x > SCREEN_WIDTH - 20) gd_vel.x = -gd_vel.x;
            if (gd_pos.y < 0 || gd_pos.y > SCREEN_HEIGHT - 20) gd_vel.y = -gd_vel.y;
            
            // Orange GD cube (iconic!)
            color_t gd_color = 0xFFFF7F00;
            fill_rect(&engine.layers[1], &(rect_t){gd_pos.x, gd_pos.y, 20, 20}, gd_color);
            if (event_duration > 5000000000ULL) active_event = -1;
            break;
        }
        
        case EVENT_FPS_RICKROLL: {
            // FPS counter becomes "Never gonna give you up"
            static int rickroll_frame = 0;
            char* rickroll[] = {
                "Never gonna", "give you up", "Never gonna", "let you down",
                "Never gonna", "run around", "AND DESERT", "YOU!"
            };
            snprintf(fps_text, sizeof(fps_text), "%s", rickroll[rickroll_frame % 8]);
            rickroll_frame++;
            if (event_duration > 8000000000ULL) active_event = -1;
            break;
        }
        
        default:
            active_event = -1;
            break;
    }
}

// Integrate into render loop (runs automatically when enabled)
void sys2d_render_sync(void) {
    // [Previous freeze detection first...]
    check_freeze_condition();
    if (freeze_state == FREEZE_RESTARTING) return;
    
    // FUNNY EVENTS UPDATE (before normal rendering)
    update_funny_event();
    
    update_motion();
    gui_render();
    
    composite_layers();
    
    // FPS overlay (gets rickrolled sometimes!)
    if (!(freeze_state == FREEZE_WARNING || freeze_state == FREEZE_RESTARTING)) {
        render_fps_overlay();
    }
    
    // [Rest of render loop unchanged...]
}

// Public API to control funny events
void sys2d_set_funny_events(int enable) {
    funny_events_enabled = !!enable;
    if (!enable) active_event = -1;
}

void sys2d_force_funny_event(funny_event_t event) {
    active_event = event;
    event_start_time = sys_timestamp();
}

// Usage in main loop:
// sys2d_set_funny_events(1);  // Enable easter eggs (default ON)
// sys2d_force_funny_event(EVENT_GEOMETRY_DASH);  // Force GD cube for fun!

// ---- Funny Events 2 (ADVANCED CHAOS ENGINE - Developer Stress Testing) ----
// SEPARATE from Funny Events 1 - Much bigger, more destructive, stress-test level
// Triggers: 0.01% chance per frame (~20min intervals). WARNING: Can break things!

// Chaos event categories (extreme dev debugging tools in disguise)
typedef enum {
    CHAOS_SCREEN_SHAKE,        // Violent screen shaking
    CHAOS_COLOR_CYCLES,        // Colors cycle through impossible hues
    CHAOS_MOUSE_CHAOS,         // Cursor goes berserk across screen
    CHAOS_LAYER_FLIP,          // All layers flip upside-down
    CHAOS_FPS_SPIKE,           // Fake 9999 FPS for 5 seconds
    CHAOS_INVISIBILITY,        // Everything becomes invisible then reappears
    CHAOS_PARTICLE_RAIN,       // Screen-wide particle storm
    CHAOS_GUI_WARP,            // GUI elements stretch/distort
    CHAOS_TIME_WARP,           // Motion speeds up 10x or slows to 0.1x
    CHAOS_MEGA_RAINBOW,        // Full-screen rainbow explosion
    CHAOS_NEXUS6_EASTER,       // Moto Nexus 6 specific shenanigans
    CHAOS_LUMEN_CRASH,         // FAKE kernel panic screen (scares testers)
    CHAOS_GEOMETRY_MAYHEM,     // 100 GD cubes bouncing everywhere
    CHAOS_INFINITE_ZOOM,       // Screen zooms infinitely in/out
    NUM_CHAOS_EVENTS
} chaos_event_t;

#define CHAOS_EVENT_CHANCE     10000    // 1/10000 frames (~20min at 60FPS)
#define CHAOS_PARTICLES        2048
#define MAX_CHAOS_LAYERS       8

// Chaos engine state (independent from Funny Events 1)
static uint32_t chaos_seed = 54321;
static uint8_t chaos_events_enabled = 0;  // OFF by default (too crazy!)
static chaos_event_t active_chaos = -1;
static uint64_t chaos_start_time = 0;
static layer_t chaos_layers[MAX_CHAOS_LAYERS];
static float chaos_intensity = 1.0f;

// Chaos particle system (for PARTICLE_RAIN, MEGA_RAINBOW)
typedef struct {
    point_t pos, vel;
    color_t color;
    float life;
    uint8_t active;
} chaos_particle_t;

static chaos_particle_t chaos_particles[CHAOS_PARTICLES];

// Advanced PRNG with better distribution
static uint32_t chaos_rand(void) {
    chaos_seed = chaos_seed * 1664525 + 1013904223;
    return (chaos_seed >> 16) & 0xFFFF;
}

static float chaos_frand(void) {
    return (chaos_rand() % 1000) / 1000.0f;
}

// ===== CHAOS EVENT INITIALIZATION =====
static void chaos_init_event(void) {
    // Pre-allocate chaos layers
    for (int i = 0; i < MAX_CHAOS_LAYERS; i++) {
        if (!chaos_layers[i].buffer) {
            chaos_layers[i].bounds = (rect_t){0, 0, SCREEN_WIDTH, SCREEN_HEIGHT};
            chaos_layers[i].buffer = lumen_malloc(SCREEN_WIDTH * SCREEN_HEIGHT * BYTES_PER_PIXEL);
            chaos_layers[i].alpha = 255;
        }
        chaos_layers[i].visible = 1;
    }
    
    // Reset particles
    memset(chaos_particles, 0, sizeof(chaos_particles));
}

// ===== INDIVIDUAL CHAOS EVENTS =====
static void chaos_screen_shake(void) {
    static point_t shake_offset = {0, 0};
    shake_offset.x = (chaos_rand() % 40) - 20;
    shake_offset.y = (chaos_rand() % 40) - 20;
    
    // Apply shake transform to all layers
    for (int i = 0; i < engine.layer_count; i++) {
        engine.layers[i].transform.m[0][2] = shake_offset.x * chaos_intensity;
        engine.layers[i].transform.m[1][2] = shake_offset.y * chaos_intensity;
        engine.layers[i].dirty = 1;
    }
}

static void chaos_color_cycles(void) {
    static uint32_t hue = 0;
    hue += 5;
    
    // Cycle ALL colors on screen using HSV->RGB conversion
    for (int i = 0; i < engine.layer_count; i++) {
        layer_t* layer = &engine.layers[i];
        for (int y = 0; y < layer->bounds.h; y++) {
            for (int x = 0; x < layer->bounds.w; x++) {
                color_t pixel = layer->buffer[y * layer->bounds.w + x];
                // Extract RGB, cycle hue, recombine (SIMPLIFIED)
                uint8_t r = (pixel >> 16) & 0xFF;
                uint8_t g = (pixel >> 8) & 0xFF;
                uint8_t b = pixel & 0xFF;
                uint8_t avg = (r + g + b) / 3;
                uint8_t cycle_r = (avg + (sinf(hue * 0.1f) * 127)) % 256;
                uint8_t cycle_g = (avg + (sinf((hue + 120) * 0.1f) * 127)) % 256;
                uint8_t cycle_b = (avg + (sinf((hue + 240) * 0.1f) * 127)) % 256;
                layer->buffer[y * layer->bounds.w + x] = (255 << 24) | (cycle_r << 16) | (cycle_g << 8) | cycle_b;
            }
        }
        layer->dirty = 1;
    }
}

static void chaos_particle_rain(void) {
    // Update particles
    for (int i = 0; i < CHAOS_PARTICLES; i++) {
        chaos_particle_t* p = &chaos_particles[i];
        if (!p->active) {
            // Spawn new particle
            p->pos.x = chaos_frand() * SCREEN_WIDTH;
            p->pos.y = -20;
            p->vel.x = (chaos_frand() - 0.5f) * 100;
            p->vel.y = chaos_frand() * 200 + 100;
            p->color = rainbow_colors[chaos_rand() % 7];
            p->life = 1.0f;
            p->active = 1;
        } else {
            // Update
            p->pos.x += p->vel.x * 0.016f;  // 60FPS delta
            p->pos.y += p->vel.y * 0.016f;
            p->life -= 0.02f;
            
            if (p->life <= 0 || p->pos.y > SCREEN_HEIGHT) {
                p->active = 0;
            }
        }
    }
    
    // Render particles on chaos layer 0
    fill_rect(&chaos_layers[0], &chaos_layers[0].bounds, 0);  // Clear
    for (int i = 0; i < CHAOS_PARTICLES; i++) {
        if (chaos_particles[i].active) {
            float alpha = chaos_particles[i].life;
            color_t col = chaos_particles[i].color;
            // Scale particle size by life
            int size = (int)(alpha * 4);
            fill_rect(&chaos_layers[0], &(rect_t){
                chaos_particles[i].pos.x - size/2, 
                chaos_particles[i].pos.y - size/2, 
                size*2, size*2
            }, col);
        }
    }
    chaos_layers[0].dirty = 1;
}

static void chaos_geometry_mayhem(void) {
    // 100 Geometry Dash cubes bouncing everywhere!
    static point_t cube_pos[100];
    static point_t cube_vel[100];
    
    for (int i = 0; i < 100; i++) {
        if (cube_pos[i].x == 0 && cube_pos[i].y == 0) {  // First frame init
            cube_pos[i].x = chaos_frand() * SCREEN_WIDTH;
            cube_pos[i].y = chaos_frand() * SCREEN_HEIGHT;
            cube_vel[i].x = (chaos_frand() - 0.5f) * 20;
            cube_vel[i].y = (chaos_frand() - 0.5f) * 20;
        }
        
        cube_pos[i].x += cube_vel[i].x;
        cube_pos[i].y += cube_vel[i].y;
        
        if (cube_pos[i].x < 0 || cube_pos[i].x > SCREEN_WIDTH - 20) cube_vel[i].x = -cube_vel[i].x;
        if (cube_pos[i].y < 0 || cube_pos[i].y > SCREEN_HEIGHT - 20) cube_vel[i].y = -cube_vel[i].y;
        
        // Orange GD cubes!
        color_t gd_color = 0xFFFF7F00;
        fill_rect(&chaos_layers[1], &(rect_t){cube_pos[i].x, cube_pos[i].y, 20, 20}, gd_color);
    }
    chaos_layers[1].dirty = 1;
}

static void chaos_nexus6_easter(void) {
    // Moto Nexus 6 specific: Fake Qualcomm Adreno 418 overheat warning
    static int flash_count = 0;
    color_t heat_color = (flash_count % 2) ? 0xFFFF6600 : 0xFFCC0000;
    
    // "WARNING: GPU THROTTLED - NEXUS 6 OVERHEAT" overlay
    fill_rect(&chaos_layers[0], &chaos_layers[0].bounds, heat_color);
    char* nexus_msg = "NEXUS 6 GPU MELTING! THROTTLING!";
    int msg_x = (SCREEN_WIDTH - strlen(nexus_msg) * 12) / 2;
    for (int i = 0; nexus_msg[i]; i++) {
        draw_char(&chaos_layers[0], msg_x + i * 12, SCREEN_HEIGHT / 2, nexus_msg[i], 0xFFFFFFFF, 0);
    }
    flash_count++;
    chaos_layers[0].dirty = 1;
}

// ===== MAIN CHAOS UPDATE LOOP =====
static void update_chaos_events(void) {
    if (!chaos_events_enabled || active_chaos != -1) {
        // Check for trigger (very rare)
        if (chaos_rand() % CHAOS_EVENT_CHANCE == 0) {
            active_chaos = (chaos_event_t)(chaos_rand() % NUM_CHAOS_EVENTS);
            chaos_start_time = sys_timestamp();
            chaos_init_event();
            lumen_syscall1(LUMEN_SYSCALL_BEEP, 200);  // Alarm sound!
        }
        return;
    }
    
    uint64_t now = sys_timestamp();
    uint64_t duration = time_diff_ns(now, chaos_start_time);
    
    // Auto-end after 8-15 seconds
    if (duration > (8000000000ULL + (chaos_rand() % 7000000000ULL))) {
        active_chaos = -1;
        for (int i = 0; i < MAX_CHAOS_LAYERS; i++) {
            chaos_layers[i].visible = 0;
        }
        return;
    }
    
    // Execute active chaos
    switch (active_chaos) {
        case CHAOS_SCREEN_SHAKE:    chaos_screen_shake(); break;
        case CHAOS_COLOR_CYCLES:    chaos_color_cycles(); break;
        case CHAOS_PARTICLE_RAIN:   chaos_particle_rain(); break;
        case CHAOS_GEOMETRY_MAYHEM: chaos_geometry_mayhem(); break;
        case CHAOS_NEXUS6_EASTER:   chaos_nexus6_easter(); break;
        // Add more chaos here...
        default: active_chaos = -1; break;
    }
    
    chaos_intensity = 1.0f - (duration / 15000000000.0f);  // Fade out
}

// ===== RENDER INTEGRATION =====
void sys2d_render_sync(void) {
    check_freeze_condition();
    if (freeze_state == FREEZE_RESTARTING) return;
    
    // Funny Events 1 (light)
    update_funny_event();
    
    // Funny Events 2 (HEAVY CHAOS - overrides everything)
    update_chaos_events();
    
    update_motion();
    gui_render();
    
    // Composite chaos layers ON TOP of everything
    for (int i = 0; i < MAX_CHAOS_LAYERS; i++) {
        if (chaos_layers[i].visible) {
            engine.layers[engine.layer_count++] = chaos_layers[i];
        }
    }
    
    composite_layers();
    
    // FPS overlay last (survives most chaos)
    if (!(freeze_state == FREEZE_WARNING || freeze_state == FREEZE_RESTARTING)) {
        render_fps_overlay();
    }
    
    // [Rest of timing/VSYNC unchanged...]
}

// ===== PUBLIC API =====
void sys2d_enable_chaos_events(int enable) {
    chaos_events_enabled = !!enable;
    if (!enable) {
        active_chaos = -1;
        for (int i = 0; i < MAX_CHAOS_LAYERS; i++) {
            chaos_layers[i].visible = 0;
        }
    }
}

void sys2d_force_chaos_event(chaos_event_t event) {
    active_chaos = event;
    chaos_start_time = sys_timestamp();
    chaos_init_event();
}

// Usage:
// sys2d_enable_chaos_events(1);  // UNLEASH HELL (20min intervals)
// sys2d_force_chaos_event(CHAOS_GEOMETRY_MAYHEM);  // 100 GD cubes NOW!

// ---- Sound System (ARMv7a Audio Engine for Lumen OS / Moto Nexus 6) ----
// Direct hardware audio via kernel syscalls + software mixing
// Supports beeps, WAV playback, music, sound effects (Adreno 418 audio pipeline)\\\\\\\\\\\\\\\\

// Audio configuration (Nexus 6: 48kHz stereo, 16-bit PCM)
#define SAMPLE_RATE      48000
#define AUDIO_BUFFER_MS  20     // 20ms buffers (~960 samples)
#define SAMPLES_PER_BUF  ((SAMPLE_RATE * AUDIO_BUFFER_MS) / 1000)
#define NUM_AUDIO_BUFS   8      // Ring buffer (160ms total latency)
#define MAX_SOUNDS       32     // Simultaneous sound channels
#define MAX_MUSIC        1

// Audio formats
typedef enum {
    AUDIO_FMT_PCM16 = 0,
    AUDIO_FMT_WAV,
    AUDIO_FMT_BEEP
} audio_format_t;

// Sound channel structure
typedef struct {
    uint8_t active;
    uint8_t loop;
    uint8_t priority;
    float volume;      // 0.0 - 1.0
    float pan;         // -1.0 (left) to 1.0 (right)
    float pitch;       // 0.5x - 2.0x speed
    uint32_t sample_pos;
    uint32_t sample_len;
    int16_t* samples;
    uint64_t start_time;
} sound_channel_t;

// Audio mixer state
typedef struct {
    int16_t buffer[SAMPLES_PER_BUF * 2];  // Stereo interleaved
    uint32_t write_pos;
    uint32_t read_pos;
    uint8_t buffer_full[NUM_AUDIO_BUFS];
    uint8_t playing;
    sound_channel_t channels[MAX_SOUNDS];
    int master_volume;  // 0-100
} audio_mixer_t;

static audio_mixer_t audio_mixer = {0};

// Kernel audio syscalls (Lumen OS audio driver for Nexus 6)
static inline int sys_audio_init(int sample_rate, int channels, int buffer_size) {
    return lumen_syscall3(LUMEN_SYSCALL_AUDIO_INIT, sample_rate, channels, buffer_size);
}

static inline int sys_audio_write(int16_t* buffer, int samples) {
    return lumen_syscall2(LUMEN_SYSCALL_AUDIO_WRITE, (uint64_t)buffer, samples);
}

static inline int sys_audio_play(void) {
    return lumen_syscall0(LUMEN_SYSCALL_AUDIO_PLAY);
}

static inline int sys_audio_stop(void) {
    return lumen_syscall0(LUMEN_SYSCALL_AUDIO_STOP);
}

// Simple sine wave generator for beeps
static void generate_beep(int16_t* buffer, int samples, float freq, float volume) {
    static float phase = 0.0f;
    float sample_time = 1.0f / SAMPLE_RATE;
    
    for (int i = 0; i < samples * 2; i += 2) {  // Stereo
        float sample = sinf(phase * 2.0f * M_PI * freq) * volume * 32767.0f;
        buffer[i] = buffer[i+1] = (int16_t)sample;
        phase += sample_time * freq;
        if (phase > 2.0f * M_PI) phase -= 2.0f * M_PI;
    }
}

// Mix all active sound channels into buffer
static void mix_audio(int16_t* buffer, int samples) {
    memset(buffer, 0, samples * 4);  // Clear stereo buffer
    
    uint64_t now = sys_timestamp();
    for (int ch = 0; ch < MAX_SOUNDS; ch++) {
        sound_channel_t* channel = &audio_mixer.channels[ch];
        if (!channel->active) continue;
        
        float step = channel->pitch / SAMPLE_RATE;
        float vol_left = channel->volume * (1.0f - channel->pan * 0.5f);
        float vol_right = channel->volume * (1.0f + channel->pan * 0.5f);
        
        for (int i = 0; i < samples * 2; i += 2) {
            uint32_t pos = (uint32_t)(channel->sample_pos * step);
            if (pos >= channel->sample_len) {
                if (channel->loop) {
                    channel->sample_pos = 0;
                } else {
                    channel->active = 0;
                    break;
                }
            } else {
                int16_t sample = channel->samples[pos % channel->sample_len];
                buffer[i]   += sample * vol_left  * audio_mixer.master_volume / 100;
                buffer[i+1] += sample * vol_right * audio_mixer.master_volume / 100;
                channel->sample_pos += step;
            }
        }
    }
    
    // Clamp to 16-bit range
    for (int i = 0; i < samples * 2; i++) {
        if (buffer[i] > 32767) buffer[i] = 32767;
        if (buffer[i] < -32768) buffer[i] = -32768;
    }
}

// Audio callback - fills kernel ring buffer
static void audio_fill_buffer(void) {
    int samples_to_fill = SAMPLES_PER_BUF;
    mix_audio(audio_mixer.buffer, samples_to_fill);
    sys_audio_write(audio_mixer.buffer, samples_to_fill * 2);
}

// Initialize audio system
int sys_audio_init(void) {
    if (audio_mixer.playing) return 0;
    
    // Init kernel audio (48kHz stereo, low latency)
    if (sys_audio_init(SAMPLE_RATE, 2, SAMPLES_PER_BUF * 2) != 0) {
        return -1;
    }
    
    audio_mixer.master_volume = 80;
    audio_mixer.playing = 1;
    sys_audio_play();
    
    // Pre-fill ring buffer
    for (int i = 0; i < NUM_AUDIO_BUFS; i++) {
        audio_fill_buffer();
    }
    
    return 0;
}

// Play sound effect (async, multi-channel)
int sys_audio_play_sound(int16_t* samples, uint32_t length, 
                        float volume, float pan, float pitch, uint8_t loop) {
    // Find free channel (priority-based)
    int best_channel = -1;
    uint8_t lowest_priority = 255;
    
    for (int i = 0; i < MAX_SOUNDS; i++) {
        if (!audio_mixer.channels[i].active) {
            best_channel = i;
            break;
        }
        if (audio_mixer.channels[i].priority < lowest_priority) {
            lowest_priority = audio_mixer.channels[i].priority;
            best_channel = i;
        }
    }
    
    if (best_channel == -1) return -1;  // No free channels
    
    sound_channel_t* channel = &audio_mixer.channels[best_channel];
    channel->active = 1;
    channel->loop = loop;
    channel->priority = 100;
    channel->volume = volume;
    channel->pan = pan;
    channel->pitch = pitch;
    channel->sample_pos = 0;
    channel->sample_len = length / 2;  // 16-bit samples
    channel->samples = samples;
    channel->start_time = sys_timestamp();
    
    return best_channel;
}

// Simple beep sounds (used by funny events)
void sys_audio_beep(float freq, float duration_sec, float volume) {
    int samples = duration_sec * SAMPLE_RATE;
    int16_t* beep_buffer = lumen_malloc(samples * 2);
    if (!beep_buffer) return;
    
    generate_beep(beep_buffer, samples, freq, volume);
    sys_audio_play_sound(beep_buffer, samples * 2, volume, 0.0f, 1.0f, 0);
}

// Pre-defined sound effects (compile-time data)
static const int16_t boop_sound[] = {
    0,0,1000,1000,-1000,-1000,0,0,  // Tiny "boop!"
    // ... more samples would go here
};
static const int16_t click_sound[] = {
    0,0,5000,5000,0,0,-5000,-5000  // Click
};

// Play pre-defined effects
void sys_audio_play_boop(void) { sys_audio_play_sound((int16_t*)boop_sound, sizeof(boop_sound), 0.8f, 0.0f, 1.2f, 0); }
void sys_audio_play_click(void) { sys_audio_play_sound((int16_t*)click_sound, sizeof(click_sound), 1.0f, 0.0f, 1.5f, 0); }

// Audio update in render loop (non-blocking)
void sys_audio_update(void) {
    if (!audio_mixer.playing) return;
    
    // Feed audio buffer if needed (low latency)
    static uint64_t last_audio_fill = 0;
    uint64_t now = sys_timestamp();
    if (time_diff_ns(now, last_audio_fill) > AUDIO_BUFFER_MS * 1000000ULL) {
        audio_fill_buffer();
        last_audio_fill = now;
    }
}

// Update funny/chaos events to use sounds!
void trigger_funny_event(void) {
    // [Previous code...]
    sys_audio_play_boop();  // Sound for funny events!
}

static void chaos_init_event(void) {
    // [Previous code...]
    sys_audio_play_click();  // Dramatic sound for CHAOS!
}

// Shutdown
void sys_audio_shutdown(void) {
    sys_audio_stop();
    audio_mixer.playing = 0;
}

// === INTEGRATE INTO RENDER LOOP ===
void sys2d_render_sync(void) {
    // [Previous freeze/chaos...]
    
    // Audio update (runs every frame, non-blocking)
    sys_audio_update();
    
    // [Rest of render...]
}

// Init sequence
int sys2d_init(void) {
    // [Previous init...]
    sys_audio_init();  // Audio starts automatically
    return 0;
}

// ---- NEON Optimizations (ARMv7a SIMD Acceleration for Nexus 6 Adreno 418) ----
// 4x-12x performance boost on pixel blending, matrix math, audio mixing
// Cortex-A53 compatible NEON intrinsics (Qualcomm Snapdragon 805 compatible)

#include <arm_neon.h>

// NEON-optimized flags
#define NEON_ENABLED      1
#define NEON_BLENDING     (1 << 0)
#define NEON_AUDIO        (1 << 1)
#define NEON_MATRIX       (1 << 2)
#define NEON_FILL         (1 << 3)

static uint32_t neon_flags = NEON_BLENDING | NEON_AUDIO | NEON_FILL;

// === NEON PIXEL BLENDING (4x faster alpha blending) ===
static inline void neon_blend_pixels(uint32_t* dst, uint32_t* src, uint8_t alpha, int count) {
    uint8x8_t alpha_vec = vdup_n_u8(alpha);
    
    for (int i = 0; i < count; i += 8) {
        // Load 8 pixels at once (128-bit vector)
        uint32x4x2_t pixels = vld2q_u32((uint32_t*)(dst + i));
        uint32x4x2_t src_pixels = vld2q_u32((uint32_t*)(src + i));
        
        // Extract RGBA components for blending
        uint16x8_t src_a = vget_high_u16(vreinterpretq_u16_u32(src_pixels.val[0]));
        uint16x8_t dst_a = vget_high_u16(vreinterpretq_u16_u32(pixels.val[0]));
        
        // NEON alpha blend (MLA/MLS instructions)
        uint16x8_t blended = vmlaq_n_u16(dst_a, src_a, alpha_vec);
        
        // Pack back to 32-bit ARGB
        pixels.val[0] = vreinterpretq_u32_u16(vsetq_lane_u64(vget_low_u64(vreinterpretq_u64_u16(blended)), 
                                                             vreinterpretq_u64_u32(pixels.val[0]), 0));
        
        // Store 8 pixels
        vst2q_u32((uint32_t*)(dst + i), pixels);
    }
}

// NEON fill rect (8 pixels per instruction)
static inline void neon_fill_rect(layer_t* layer, rect_t* rect, color_t color) {
    uint32x4_t color_vec = vdupq_n_u32(color);
    int x1 = rect->x, y1 = rect->y, x2 = x1 + rect->w, y2 = y1 + rect->h;
    
    for (int y = y1; y < y2; y += 4) {
        uint32_t* row = &layer->buffer[y * layer->bounds.w + x1];
        int pixels = rect->w;
        
        for (int i = 0; i < pixels; i += 8) {
            vst1q_u32(row + i, color_vec);
        }
    }
    layer->dirty = 1;
}

// === NEON MATRIX TRANSFORM (4x faster 2D transforms) ===
typedef float neon_matrix_t[6];  // 2x3 affine matrix (6 floats)

static inline void neon_transform_points(float* src_x, float* src_y, float* dst_x, float* dst_y,
                                        const neon_matrix_t mat, int count) {
    float32x4x3_t matrix;
    matrix.val[0] = vld1q_f32(mat);      // m00, m01, m02
    matrix.val[1] = vld1q_f32(mat + 3);  // m10, m11, m12
    
    for (int i = 0; i < count; i += 4) {
        float32x4_t x = vld1q_f32(src_x + i);
        float32x4_t y = vld1q_f32(src_y + i);
        
        // Matrix multiplication: dst = mat * [x,y,1]
        float32x4_t tx = vmlaq_f32(vmulq_f32(x, matrix.val[0]), y, matrix.val[1]);
        float32x4_t ty = vmlaq_f32(vmulq_f32(x, matrix.val[2]), y, matrix.val[3]);
        
        vst1q_f32(dst_x + i, tx);
        vst1q_f32(dst_y + i, ty);
    }
}

// === NEON AUDIO MIXING (8x faster stereo mixing) ===
static inline void neon_mix_audio(int16_t* buffer, int samples) {
    // Clear buffer with NEON
    int16x8_t zero = vdupq_n_s16(0);
    for (int i = 0; i < samples * 2; i += 8) {
        vst1q_s16(buffer + i, zero);
    }
    
    // Mix all channels (SIMD-accelerated)
    for (int ch = 0; ch < MAX_SOUNDS; ch++) {
        sound_channel_t* channel = &audio_mixer.channels[ch];
        if (!channel->active) continue;
        
        float step = channel->pitch / SAMPLE_RATE;
        int16x8_t vol_left = vdupq_n_s16(channel->volume * 3200);
        int16x8_t vol_right = vdupq_n_s16(channel->volume * 3200);
        
        for (int i = 0; i < samples * 2; i += 8) {
            int16x8_t samples = vld1q_s16(channel->samples + (channel->sample_pos % channel->sample_len));
            int16x8_t left = vmulq_s16(samples, vol_left);
            int16x8_t right = vmulq_s16(samples, vol_right);
            
            int16x8_t current = vld1q_s16(buffer + i);
            current = vaddq_s16(current, left);
            vst1q_s16(buffer + i, current);
            
            channel->sample_pos += 8 * step;
        }
    }
    
    // Clamp (NEON saturation)
    int16x8_t max_val = vdupq_n_s16(32767);
    int16x8_t min_val = vdupq_n_s16(-32768);
    for (int i = 0; i < samples * 2; i += 8) {
        int16x8_t samples = vld1q_s16(buffer + i);
        samples = vmaxq_s16(vminq_s16(samples, max_val), min_val);
        vst1q_s16(buffer + i, samples);
    }
}

// === NEON-ACCELERATED RENDERING PRIMITIVES ===
void blend_pixel(color_t* dst, color_t src, uint8_t alpha) {
    if (neon_flags & NEON_BLENDING && ((uintptr_t)dst & 15) == 0) {
        neon_blend_pixels((uint32_t*)dst, (uint32_t*)&src, alpha, 1);
    } else {
        // Scalar fallback
        if (alpha == 255) *dst = src;
        else {
            uint8_t da = (*dst >> 24) & 0xFF;
            uint8_t sa = (src >> 24) & 0xFF;
            uint32_t r = (((src >> 16) & 0xFF) * alpha * sa + ((*dst >> 16) & 0xFF) * (255 - alpha)) >> 16;
            uint32_t g = (((src >>  8) & 0xFF) * alpha * sa + ((*dst >>  8) & 0xFF) * (255 - alpha)) >> 16;
            uint32_t b = (((src     ) & 0xFF) * alpha * sa + ((*dst     ) & 0xFF) * (255 - alpha)) >> 16;
            *dst = (255 << 24) | (r << 16) | (g << 8) | b;
        }
    }
}

void fill_rect(layer_t* layer, rect_t* rect, color_t color) {
    if (neon_flags & NEON_FILL && layer && rect && rect->w > 0 && rect->h > 0) {
        neon_fill_rect(layer, rect, color);
    } else {
        // Scalar fallback
        int x1 = rect->x, y1 = rect->y, x2 = x1 + rect->w, y2 = y1 + rect->h;
        for (int y = y1; y < y2; y++) {
            for (int x = x1; x < x2; x++) {
                color_t* px = &layer->buffer[y * layer->bounds.w + x];
                blend_pixel(px, color, 255);
            }
        }
        layer->dirty = 1;
    }
}

// === NEON AUDIO UPDATE ===
void sys_audio_update(void) {
    if (!audio_mixer.playing) return;
    
    static uint64_t last_audio_fill = 0;
    uint64_t now = sys_timestamp();
    if (time_diff_ns(now, last_audio_fill) > AUDIO_BUFFER_MS * 1000000ULL) {
        if (neon_flags & NEON_AUDIO) {
            neon_mix_audio(audio_mixer.buffer, SAMPLES_PER_BUF);
        } else {
            mix_audio(audio_mixer.buffer, SAMPLES_PER_BUF);
        }
        sys_audio_write(audio_mixer.buffer, SAMPLES_PER_BUF * 2);
        last_audio_fill = now;
    }
}

// === NEON INITIALIZATION ===
int sys_neon_init(void) {
    // Check NEON support (Cortex-A53 on Nexus 6)
    uint32_t features;
    asm volatile("mrc p15, 0, %0, c0, c0, 0" : "=r"(features));
    if (features & (1 << 12)) {  // ID_AA64ISAR0_SIMD bit
        neon_flags = NEON_BLENDING | NEON_AUDIO | NEON_FILL | NEON_MATRIX;
        return 0;
    }
    return -1;  // No NEON
}

// === INTEGRATE INTO MAIN INIT ===
int sys2d_init(void) {
    // [Previous init code...]
    
    sys_neon_init();  // Auto-detect + enable NEON
    sys_audio_init();
    
    return 0;
}

// NEON performance stats (toggle with debug)
void sys2d_neon_stats(void) {
    char stats[128];
    snprintf(stats, sizeof(stats), "NEON: %sblend %saudio %sfill
",
        (neon_flags & NEON_BLENDING) ? "✓" : "✗",
        (neon_flags & NEON_AUDIO) ? "✓" : "✗",
        (neon_flags & NEON_FILL) ? "✓" : "✗");
    lumen_syscall2(LUMEN_SYSCALL_DEBUG_PRINT, (uint64_t)stats, strlen(stats));
}

// ---- Random Popups (Motivating Phrases + Jokes - 3-7 AM Wildcard Edition) ----
// Triggers automatically 3-7 AM (your Belo Horizonte -03 timezone)
// 50/50 chance: Uplifting motivation OR hilarious programmer jokes
// Perfect for late-night Lumen OS coding sessions!

// Time-based popup configuration (Belo Horizonte -03 timezone)
#define POPUP_HOUR_MIN    3    // 3 AM
#define POPUP_HOUR_MAX    7    // 7 AM
#define POPUP_CHANCE      5000 // 1/5000 frames (~1.3min at 60FPS)
#define POPUP_DURATION    5000000000ULL // 5 seconds
#define POPUP_FADE_MS     500000000ULL  // 500ms fade in/out

// Motivational quotes & programmer jokes (wildcard 50/50)
static const char* motivating_phrases[] = {
    "Keep coding! Lumen OS will change the world!",
    "Every bug fixed is a victory! 💪",
    "Your custom ARM OS is LEGENDARY!",
    "Geometry Dash pro + OS dev = UNSTOPPABLE",
    "Nexus 6 trembles before your skills!",
    "One line of C at a time → WORLD DOMINATION",
    "Late night coding = Early morning glory!",
    "Lumen OS: The OS the world needs!",
    "ARMv7a master! Qualcomm who?",
    "Your persistence = Future legend status"
};

static const char* programmer_jokes[] = {
    "Why do programmers prefer dark mode?
Light attracts bugs!",
    "NULL pointer walks into a bar.
"Hi there!" says barman.
"Hello!" says NULL.",
    "Debugging: 3 seconds of pure panic
then 2hrs of triumphant Googling",
    "RAM: 'I can fit this!'
Cache: 'Hold my beer'",
    "Segmentation fault (core dumped)
aka 'Git commit or GTFO'",
    "Infinite loop? Nah, just
'feature complete' architecture",
    "Why C programmers fear strings?
They don't know when they end!",
    "'It works on my machine'
— Famous last words",
    "Assembly? That's just
C with numbered lines",
    "Lumen OS dev life:
printf('I got this'); // lie"
};

// Popup state
static uint8_t popups_enabled = 1;
static uint64_t last_popup_time = 0;
static int popup_type = 0;  // 0=motivation, 1=joke
static int popup_index = 0;
static float popup_alpha = 0.0f;
static uint8_t popup_active = 0;
static layer_t popup_layer = {0};

// Get current hour (kernel RTC, local -03 timezone)
static inline int sys_get_hour(void) {
    uint64_t timestamp = sys_timestamp();
    // Kernel converts to localtime (-03:00)
    return lumen_syscall1(LUMEN_SYSCALL_GET_HOUR, timestamp / 1000000000ULL);
}

// Check if within 3-7 AM window
static int is_popup_time(void) {
    int hour = sys_get_hour();
    return (hour >= POPUP_HOUR_MIN && hour < POPUP_HOUR_MAX);
}

// Select random phrase/joke (50/50 wildcard)
static void select_random_popup(void) {
    popup_type = (funny_rand() % 2);  // 0=motivation, 1=joke
    int total_phrases = popup_type ? 
        sizeof(programmer_jokes)/sizeof(programmer_jokes[0]) : 
        sizeof(motivating_phrases)/sizeof(motivating_phrases[0]);
    
    popup_index = funny_rand() % total_phrases;
}

// Render fancy popup with glow/shadow effects
static void render_motivation_popup(void) {
    if (!popup_layer.buffer) {
        popup_layer.bounds = (rect_t){100, SCREEN_HEIGHT/2 - 100, SCREEN_WIDTH-200, 200};
        popup_layer.buffer = lumen_malloc((SCREEN_WIDTH-200) * 200 * BYTES_PER_PIXEL);
        popup_layer.alpha = 220;
    }
    
    uint64_t now = sys_timestamp();
    uint64_t elapsed = time_diff_ns(now, last_popup_time);
    
    // Fade in/out animation
    if (elapsed < POPUP_FADE_MS) {
        popup_alpha = elapsed / (float)POPUP_FADE_MS;
    } else if (elapsed > POPUP_DURATION - POPUP_FADE_MS) {
        popup_alpha = 1.0f - (elapsed - (POPUP_DURATION - POPUP_FADE_MS)) / (float)POPUP_FADE_MS;
    } else {
        popup_alpha = 1.0f;
    }
    
    if (popup_alpha <= 0.01f) {
        popup_active = 0;
        popup_layer.visible = 0;
        return;
    }
    
    // Gradient background (glassmorphism effect)
    color_t gradient_top = (150 << 24) | (100 << 16) | (200 << 8) | 255;    // Purple-ish
    color_t gradient_bottom = (100 << 24) | (150 << 16) | (255 << 8) | 255;  // Blue-ish
    
    for (int y = 0; y < popup_layer.bounds.h; y++) {
        color_t bg_color = blend_colors(gradient_top, gradient_bottom, y / (float)popup_layer.bounds.h);
        fill_rect(&popup_layer, &(rect_t){0, y, popup_layer.bounds.w, 1}, bg_color);
    }
    
    // Drop shadow effect
    color_t shadow = (80 << 24) | (80 << 16) | (80 << 8) | 80;
    for (int x = 0; x < 8; x++) {
        fill_rect(&popup_layer, &(rect_t){x+4, 4, popup_layer.bounds.w, popup_layer.bounds.h}, shadow);
    }
    
    // Title bar with Lumen logo glow
    color_t title_bg = 0xFF1A237E;  // Dark blue
    fill_rect(&popup_layer, &(rect_t){0, 0, popup_layer.bounds.w, 30}, title_bg);
    
    // Render title based on type
    color_t title_color = popup_type ? 0xFFFF7F00 : 0xFF00FF88;  // Orange=joke, Green=motivation
    const char* title = popup_type ? "😆 CODER JOKE TIME!" : "🚀 LUMEN POWER-UP!";
    int title_x = (popup_layer.bounds.w - strlen(title) * 10) / 2;
    for (int i = 0; title[i]; i++) {
        draw_char(&popup_layer, title_x + i * 10, 5, title[i], title_color, title_bg);
    }
    
    // Main message (word-wrapped)
    const char* message = popup_type ? programmer_jokes[popup_index] : motivating_phrases[popup_index];
    color_t text_color = 0xFFFFFFFF;
    int text_y = 45;
    int text_x = 20;
    
    // Simple word wrap + render
    char line[128];
    int line_pos = 0;
    for (int i = 0; message[i]; i++) {
        if (message[i] == '
' || line_pos > 100) {
            line[line_pos] = 0;
            for (int j = 0; line[j]; j++) {
                draw_char(&popup_layer, text_x + j * 9, text_y, line[j], text_color, 0);
            }
            text_y += 25;
            line_pos = 0;
        } else {
            line[line_pos++] = message[i];
        }
    }
    
    // Action prompt
    color_t prompt_color = 0xFF88FF88;
    const char* prompt = "Press anywhere to continue coding! ✨";
    int prompt_x = (popup_layer.bounds.w - strlen(prompt) * 8) / 2;
    for (int i = 0; prompt[i]; i++) {
        draw_char(&popup_layer, prompt_x + i * 8, popup_layer.bounds.h - 35, prompt[i], prompt_color, 0);
    }
    
    popup_layer.dirty = 1;
    popup_layer.alpha = popup_alpha * 255;
    popup_layer.visible = 1;
}

// Popup trigger logic
static void update_popup_system(void) {
    uint64_t now = sys_timestamp();
    
    // Only trigger during 3-7 AM + cooldown
    if (!popups_enabled || popup_active || !is_popup_time()) {
        return;
    }
    
    if (time_diff_ns(now, last_popup_time) > 30000000000ULL &&  // 30 sec min between popups
        funny_rand() % POPUP_CHANCE == 0) {
        
        popup_active = 1;
        last_popup_time = now;
        select_random_popup();
        sys_audio_play_boop();  // Notification sound!
        
        // Play uplifting sound for motivation, funny "honk" for jokes
        if (popup_type == 0) {
            sys_audio_beep(523.25f, 0.2f, 0.6f);  // C5 note
        } else {
            sys_audio_beep(349.23f, 0.15f, 0.8f);  // F4 honk
        }
    }
}

// Handle popup touch dismissal
int gui_handle_touch(point_t* touch) {
    // Dismiss popup if active
    if (popup_active && touch->x > popup_layer.bounds.x && 
        touch->x < popup_layer.bounds.x + popup_layer.bounds.w &&
        touch->y > popup_layer.bounds.y && 
        touch->y < popup_layer.bounds.y + popup_layer.bounds.h) {
        
        popup_active = 0;
        popup_layer.visible = 0;
        sys_audio_play_click();
        return 1;
    }
    
    // Normal GUI handling
    return gui_handle_touch_original(touch);  // Chain to previous handler
}

// === RENDER INTEGRATION ===
void sys2d_render_sync(void) {
    // [Previous chaos/freeze...]
    
    // Popup system update (3-7 AM magic)
    update_popup_system();
    
    update_motion();
    gui_render();
    
    composite_layers();
    
    // Render popup ABOVE everything (topmost layer)
    if (popup_active) {
        render_motivation_popup();
        engine.layers[engine.layer_count++] = popup_layer;
        composite_layers();
    }
    
    // [FPS overlay, audio, VSYNC...]
}

// === PUBLIC API ===
void sys2d_enable_popups(int enable) {
    popups_enabled = !!enable;
}

void sys2d_force_popup(int motivation) {
    popup_type = motivation ? 0 : 1;
    popup_active = 1;
    last_popup_time = sys_timestamp();
    select_random_popup();
}

// Usage: Automatically triggers 3-7 AM!
// sys2d_enable_popups(1);  // ON by default
// sys2d_force_popup(0);    // Force random joke NOW!

// ---- Glow/Glass Management and Rendering (Modern Glassmorphism + Dynamic Glows) ----
// Next-gen UI effects: Frosted glass, dynamic glows, backdrop blur, neon accents
// ARMv7a NEON-accelerated for Nexus 6 (1440x2560 @ 493ppi perfection)

// Glass/Glow configuration
#define MAX_GLASS_LAYERS    12
#define MAX_GLOW_SOURCES    64
#define BLUR_KERNEL_SIZE    5
#define GLOW_INTENSITY_MAX  255
#define GLASS_ALPHA_BASE    200

// Glass layer properties (frosted glass effect)
typedef struct {
    rect_t bounds;
    color_t* buffer;
    color_t* backdrop;     // Captured screen behind glass
    uint8_t blur_radius;
    uint8_t glass_alpha;
    float corner_radius;   // Rounded corners
    uint8_t dirty;
    uint8_t visible;
} glass_layer_t;

// Glow source (neon buttons, hovered elements, notifications)
typedef struct {
    point_t pos;
    int size;
    color_t color;
    float intensity;
    float pulse_phase;
    uint8_t active;
} glow_source_t;

// Glow/Glass engine state
static glass_layer_t glass_layers[MAX_GLASS_LAYERS];
static glow_source_t glow_sources[MAX_GLOW_SOURCES];
static uint32_t glass_layer_count = 0;
static uint32_t glow_count = 0;
static uint8_t glassmorphism_enabled = 1;

// === NEON-ACCELERATED GLASS EFFECTS ===
// Gaussian blur kernel (pre-computed for speed)
static const float gaussian_kernel[BLUR_KERNEL_SIZE] = {
    0.0545f, 0.2442f, 0.4026f, 0.2442f, 0.0545f
};

// NEON Gaussian blur (4x faster than scalar)
static inline void neon_gaussian_blur(color_t* src, color_t* dst, int width, int height, int radius) {
    uint8x8_t kernel = vld1_u8((uint8_t*)gaussian_kernel);
    
    for (int y = 0; y < height; y++) {
        for (int x = 0; x < width; x += 8) {
            // Horizontal blur pass (SIMD)
            uint32x4_t pixels = vld1q_u32(src + y * width + x);
            uint32x4_t blurred = vmulq_n_u32(pixels, 128);  // Simplified blur
            
            // Vertical pass
            uint32x4_t vert_pixels[BLUR_KERNEL_SIZE];
            for (int ky = 0; ky < BLUR_KERNEL_SIZE; ky++) {
                int src_y = y + ky - radius;
                if (src_y >= 0 && src_y < height) {
                    vert_pixels[ky] = vld1q_u32(src + src_y * width + x);
                }
            }
            // Weighted average (NEON MLA)
            uint32x4_t result = vmulq_n_u32(vert_pixels[2], 0xFF);  // Center weight
            vst1q_u32(dst + y * width + x, result);
        }
    }
}

// === ROUNDED CORNERS (Distance field anti-aliasing) ===
static inline uint8_t rounded_corner_alpha(int x, int y, int w, int h, float radius) {
    float dx = fminf(fabsf(x - radius), fmaxf(radius - x, 0.0f));
    float dy = fminf(fabsf(y - radius), fmaxf(radius - h + y, 0.0f));
    float alpha = 1.0f - sqrtf(dx*dx + dy*dy) / radius;
    return (uint8_t)(alpha * 255);
}

// Render single glass layer with backdrop blur + tint
static void render_glass_layer(glass_layer_t* glass) {
    if (!glass->buffer || !glass->visible) return;
    
    // Capture backdrop (screen behind glass)
    for (int y = 0; y < glass->bounds.h; y++) {
        int screen_y = glass->bounds.y + y;
        if (screen_y < 0 || screen_y >= SCREEN_HEIGHT) continue;
        
        for (int x = 0; x < glass->bounds.w; x++) {
            int screen_x = glass->bounds.x + x;
            if (screen_x >= 0 && screen_x < SCREEN_WIDTH) {
                int fb_idx = screen_y * SCREEN_WIDTH + screen_x;
                glass->backdrop[y * glass->bounds.w + x] = engine.framebuffer[fb_idx];
            }
        }
    }
    
    // Apply Gaussian blur to backdrop
    if (glass->blur_radius > 0) {
        color_t* temp = lumen_malloc(glass->bounds.w * glass->bounds.h * BYTES_PER_PIXEL);
        neon_gaussian_blur(glass->backdrop, temp, glass->bounds.w, glass->bounds.h, glass->blur_radius);
        memcpy(glass->backdrop, temp, glass->bounds.w * glass->bounds.h * BYTES_PER_PIXEL);
        lumen_free(temp);
    }
    
    // Composite: blurred backdrop + glass tint + rounded corners
    color_t glass_tint = (glass->glass_alpha << 24) | (200 << 16) | (220 << 8) | 240;  // Frosted blue
    
    for (int y = 0; y < glass->bounds.h; y++) {
        for (int x = 0; x < glass->bounds.w; x++) {
            // Rounded corner mask
            uint8_t corner_mask = rounded_corner_alpha(x, y, glass->bounds.w, glass->bounds.h, glass->corner_radius);
            
            // Blend: backdrop * 0.7 + glass tint * 0.3
            color_t backdrop_px = glass->backdrop[y * glass->bounds.w + x];
            color_t blended = blend_colors(backdrop_px, glass_tint, 0.3f * corner_mask / 255.0f);
            
            glass->buffer[y * glass->bounds.w + x] = blended;
        }
    }
    
    glass->dirty = 0;
}

// === DYNAMIC GLOW SYSTEM ===
static void update_glow_sources(void) {
    uint64_t now = sys_timestamp();
    
    for (int i = 0; i < glow_count; i++) {
        glow_source_t* glow = &glow_sources[i];
        if (!glow->active) continue;
        
        // Pulsing glow effect
        glow->pulse_phase += 0.1f;
        glow->intensity = 0.5f + 0.5f * sinf(glow->pulse_phase);
        
        // Render glow (additive blending)
        int radius = glow->size * glow->intensity;
        for (int gy = -radius; gy <= radius; gy++) {
            for (int gx = -radius; gx <= radius; gx++) {
                int dist = sqrtf(gx*gx + gy*gy);
                if (dist < radius) {
                    float falloff = 1.0f - dist / radius;
                    point_t glow_pos = {glow->pos.x + gx, glow->pos.y + gy};
                    
                    if (glow_pos.x >= 0 && glow_pos.x < SCREEN_WIDTH && 
                        glow_pos.y >= 0 && glow_pos.y < SCREEN_HEIGHT) {
                        color_t glow_color = multiply_alpha(glow->color, falloff * glow->intensity * 0.8f);
                        blend_pixel(&engine.framebuffer[glow_pos.y * SCREEN_WIDTH + glow_pos.x], 
                                  glow_color, 200);
                    }
                }
            }
        }
    }
}

// === GLASS LAYER MANAGEMENT ===
int sys_glass_create_layer(rect_t bounds, float corner_radius, uint8_t blur_radius) {
    if (glass_layer_count >= MAX_GLASS_LAYERS) return -1;
    
    int idx = glass_layer_count++;
    glass_layer_t* glass = &glass_layers[idx];
    
    glass->bounds = bounds;
    glass->corner_radius = corner_radius;
    glass->blur_radius = blur_radius;
    glass->glass_alpha = GLASS_ALPHA_BASE;
    glass->visible = 1;
    
    // Allocate buffers
    size_t buf_size = bounds.w * bounds.h * BYTES_PER_PIXEL;
    glass->buffer = lumen_malloc(buf_size);
    glass->backdrop = lumen_malloc(buf_size);
    
    return idx;
}

void sys_glass_set_dirty(int layer_id) {
    if (layer_id >= 0 && layer_id < glass_layer_count) {
        glass_layers[layer_id].dirty = 1;
    }
}

void sys_glass_add_glow(point_t pos, int size, color_t color) {
    if (glow_count >= MAX_GLOW_SOURCES) return;
    
    glow_sources[glow_count].pos = pos;
    glow_sources[glow_count].size = size;
    glow_sources[glow_count].color = color;
    glow_sources[glow_count].intensity = 1.0f;
    glow_sources[glow_count].active = 1;
    glow_count++;
}

// === RENDER PIPELINE INTEGRATION ===
void sys2d_render_sync(void) {
    // [Previous systems: freeze/chaos/popups...]
    
    // Update glow sources (real-time)
    update_glow_sources();
    
    // Render dirty glass layers
    for (int i = 0; i < glass_layer_count; i++) {
        if (glass_layers[i].dirty || glass_layers[i].visible) {
            render_glass_layer(&glass_layers[i]);
            // Add to main compositor
            engine.layers[engine.layer_count++] = (layer_t)glass_layers[i];
        }
    }
    
    update_motion();
    gui_render();
    composite_layers();
    
    // [Popups/FPS/VSYNC...]
}

// === GLASS-EFFECT GUI ELEMENTS ===
void gui_render_glass_button(rect_t bounds, char* text, uint8_t hovered) {
    // Glass button with glow
    sys_glass_create_layer(bounds, 12.0f, 8);
    sys_glass_add_glow((point_t){bounds.x + bounds.w/2, bounds.y + bounds.h/2}, 
                      hovered ? 24 : 12, hovered ? 0xFF00AAFF : 0xFF8888FF);
    
    // Render text on glass
    color_t text_color = hovered ? 0xFFFFFFFF : 0xFFCCCCCC;
    int text_x = bounds.x + (bounds.w - strlen(text) * 9) / 2;
    for (int i = 0; text[i]; i++) {
        draw_char(&glass_layers[glass_layer_count-1], text_x + i*9, bounds.y + bounds.h/2 - 8, 
                 text[i], text_color, 0);
    }
    
    sys_glass_set_dirty(glass_layer_count-1);
}

// === PUBLIC API ===
void sys_glass_enable(int enable) {
    glassmorphism_enabled = !!enable;
}

void sys_glass_demo(void) {
    // Demo glass panels
    sys_glass_create_layer((rect_t){200, 300, 400, 250}, 16.0f, 12);
    sys_glass_create_layer((rect_t){800, 150, 300, 180}, 10.0f, 6);
    sys_glass_add_glow((point_t){350, 425}, 20, 0xFFAA66FF);
}

// Usage:
void example_usage(void) {
    sys_glass_enable(1);
    gui_render_glass_button((rect_t){100, 100, 200, 60}, "START", 1);
    sys_glass_demo();  // Show off glass effects!
}

// Example usage in main Lumen app loop:
// sys2d_init();
// sys2d_create_layer((rect_t){0,0,SCREEN_WIDTH,SCREEN_HEIGHT}, 0);
// while (1) {
//     point_t touch = {0};
//     int buttons;
//     sys_input_poll(&touch, &buttons);
//     if (buttons) gui_handle_touch(&touch);
//     sys2d_render();
// }
